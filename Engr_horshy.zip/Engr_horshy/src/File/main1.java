package File;

public class main1 {
    public static void main(String[] args) {
         /*JFrame frame = new JFrame(); // thi create a frame
        frame.setTitle("JFrame titles goes here");
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420,420); // this set x - dimension and y- dimension
        frame.setVisible(true); // this will make the frame visible
        ImageIcon image = new ImageIcon("C:\\Users\\HP.COM\\IdeaProjects\\Engr_horshy\\src\\File\\logo.jpg");// create an imageicon
        frame.setIconImage(image.getImage());// change icon of frame
        frame.getContentPane().setBackground(new Color(123,50,250)); // set background color to green
        */
        MyFrame myFrame = new MyFrame();
    }
}
